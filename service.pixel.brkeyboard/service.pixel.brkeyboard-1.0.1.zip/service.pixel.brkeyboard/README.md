<h1>Teclado On Screen Português Brasil para Kodi</h1>

Teclado virtual com suporte a acentos e caracteres especiais.

Link para download:
https://github.com/josemoraes99/kodirepo/raw/master/service.pixel.brkeyboard/service.pixel.brkeyboard-1.0.0.zip

<h2>Instalação</h2>

- Abrir o Kodi >> Sistema >> Add-ons >> Instalar a partir de um arquivo ZIP

- Procurar o arquivo service.pixel.brkeyboard.zip

- Após instalar o add-on, reiniciar o Kodi para que ele reconheça os novos teclados.

<h2>Escolher os teclados</h2>

- Abrir o Kodi >> Sistema >> Aparência

- (certifique-se de que os "Níveis de Ajustes" esteja pelo menos em Padrão)

- Internacional >> Layouts do Teclado

- Selecione os teclados "Portuguese (Brazil) QUERTY" e "Special QUERTY"



<h1>Canais Pixel</h1>

Mod do addon TIABET do leandrotsampa

- Adiciona picons dos canais
- Cria grupos de canais
- Oculta canais que iniciam com PG-
- Oculta canais informativos

Link para download:
https://github.com/josemoraes99/kodirepo/raw/master/plugin.video.pixel.canais/plugin.video.pixel.canais-1.0.5.zip


<h2>Instalação</h2>

- Abrir o Kodi >> Sistema >> Add-ons >> Instalar a partir de um arquivo ZIP
- Procurar o arquivo plugin.video.pixel.canais-1.0.5.zip

<h2>Utilização</h2>

- Abrir menu principal > Video > Add-ons
- Escolha Canais Pixel
- Escolha a opção desejada (pode ser mais que uma)
- Reinicie o Kodi para aplicar

<h2>Se faltar algum picon</h2>

Consultar o arquivo no Media Player do Pixel:

/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/plugin.video.pixel.canais/pics_nao_encontradas.txt

Copie desse arquivo os canais que faltam e coloque no grupo do Whatsapp ou no forum

<h2>Se quiser personalizar com seus proprios picons</h2>

Para editar o addon é simples, ele é um zip, as imagens ficam em resources/media.

Para completar os que faltam é só olhar no log no pixel em /storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/plugin.video.pixel.canais/pics_nao_encontradas.txt

As imagens tem que ser de tamanho 220x132 e pode ser jpg ou png.

Se  alterar alguma imagem e ela nao atualizar, as vezes tem que apagar a pasta /storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/userdata/Thumbnails pro kodi carregar novamente.

No arquivo canaisnet.txt contém os nomes dos canais que serão ocultos na opção "Ocultar canais informativos NET".

